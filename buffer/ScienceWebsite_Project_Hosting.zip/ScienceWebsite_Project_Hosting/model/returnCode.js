module.exports = {
    clientError: "1",
    serverError: "2",
    serviceError: "3",
    dataError: "4",
    success: "999999",
};