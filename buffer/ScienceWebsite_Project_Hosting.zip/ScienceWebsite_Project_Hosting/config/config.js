//Before starting, please fill this file with correct information
//Once it is done, just rename it as config.js

module.exports = {
	port : 7777,
	dbUrl: 'mongodb://testUser:testPass@ds111568.mlab.com:11568/scienceweb',
	//dbUrl: 'mongodb://testUser:testPass@ds047692.mlab.com:47692/lm_1',
	sessionSecret : 'ai',
	consumerKey: 'my_twitter_consumer_key',
    consumerSecret: 'my_twitter_consumer_key'
}